#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>
#include "SatelliteComms.h"

/**
 * Example application demonstrating the use of the SatelliteComms API.
 * This creates a satellite in circular orbit with a beam pointing outward,
 * then tests reception at various points in space.
 */
int main() {
    // Configuration parameters
    std::vector<TimedSatelliteState> stateTimeline;
    
    // Define orbital and beam parameters
    constexpr double orbitRadius = 10000.0;  // Units (e.g., km)
    constexpr double planetRadius = 6371.0;  // Earth radius in km
    constexpr double beamConeAngle = 15.0;   // 15 degrees cone angle
    
    // Create timeline with 10 samples over one full orbit
    constexpr int numSamples = 10;
    constexpr double timeStep = 1000.0;  // Each sample 1000 seconds apart
    
    for (int i = 0; i < numSamples; ++i) {
        double time = i * timeStep;
        double angle = (2 * M_PI * i) / numSamples;
        
        // Calculate position in circular orbit (XY plane)
        Vector3 position = {
            orbitRadius * std::cos(angle),
            orbitRadius * std::sin(angle),
            0.0
        };
        
        // Beam direction pointing radially outward from planet center
        Vector3 beamDirection = position;
        
        // Normalize the beam direction
        double mag = beamDirection.magnitude();
        beamDirection = {
            beamDirection.x / mag,
            beamDirection.y / mag,
            beamDirection.z / mag
        };
        
        // Add the state to our timeline
        stateTimeline.push_back({time, {position, beamDirection}});
    }
    
    // Initialize the satellite communications system
    SatelliteComms comms(planetRadius, beamConeAngle, stateTimeline);
    
    // Set output formatting for clarity
    std::cout << std::fixed << std::setprecision(2);
    
    // Test Case 1: Point directly in satellite's beam path
    {
        Vector3 pointP = {15000.0, 0.0, 0.0};  // Further out along X-axis at t=0
        double time = 0.0;
        
        bool canReceive = comms.canReceiveTransmission(pointP, time);
        
        std::cout << "Case 1: Point in beam path" << std::endl;
        std::cout << "  - Location: (" << pointP.x << ", " << pointP.y << ", " << pointP.z << ")" << std::endl;
        std::cout << "  - Time: " << time << std::endl;
        std::cout << "  - Can receive? " << (canReceive ? "Yes" : "No") << std::endl;
    }
    
    // Test Case 2: Point outside beam cone
    {
        Vector3 pointP = {15000.0, 5000.0, 0.0};  // Off to the side, outside 15 degree cone
        double time = 0.0;
        
        bool canReceive = comms.canReceiveTransmission(pointP, time);
        
        std::cout << "\nCase 2: Point outside beam cone" << std::endl;
        std::cout << "  - Location: (" << pointP.x << ", " << pointP.y << ", " << pointP.z << ")" << std::endl;
        std::cout << "  - Time: " << time << std::endl;
        std::cout << "  - Can receive? " << (canReceive ? "Yes" : "No") << std::endl;
        
        // Find next available transmission time
        auto nextTime = comms.nextTransmissionTime(pointP, time);
        if (nextTime) {
            std::cout << "  - Next available time: " << *nextTime << std::endl;
            
            // Verify transmission is possible at the returned time
            bool verifyReceive = comms.canReceiveTransmission(pointP, *nextTime);
            std::cout << "  - Verified reception at next time: " << (verifyReceive ? "Yes" : "No") << std::endl;
        } else {
            std::cout << "  - No transmission possible within timeline" << std::endl;
        }
    }
    
    // Test Case 3: Point behind planet (occlusion test)
    {
        Vector3 pointP = {-8000.0, 0.0, 0.0};  // Behind planet relative to satellite at t=0
        double time = 0.0;
        
        bool canReceive = comms.canReceiveTransmission(pointP, time);
        
        std::cout << "\nCase 3: Point behind planet" << std::endl;
        std::cout << "  - Location: (" << pointP.x << ", " << pointP.y << ", " << pointP.z << ")" << std::endl;
        std::cout << "  - Time: " << time << std::endl;
        std::cout << "  - Can receive? " << (canReceive ? "Yes" : "No") << std::endl;
        
        // Find next available transmission time
        auto nextTime = comms.nextTransmissionTime(pointP, time);
        if (nextTime) {
            std::cout << "  - Next available time: " << *nextTime << std::endl;
            
            // Get satellite position at this time
            SatelliteState state = comms.interpolateState(*nextTime);
            std::cout << "  - Satellite position at next time: ("
                      << state.position.x << ", " 
                      << state.position.y << ", "
                      << state.position.z << ")" << std::endl;
        } else {
            std::cout << "  - No transmission possible within timeline" << std::endl;
        }
    }
    
    return 0;
}
